package ec.edu.ups.appdis.citasmedicas;

import android.app.Activity;
import android.app.Notification;
import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.Date;

public class ListarCitasActivity extends ListarActivity {

    @Override
    public String[] camposBusqueda() {
        return new String[]{
                "doctor", "paciente"
        };
    }

    @Override
    public void bindView(final JSONObject json, View convertView) {
        TextView textMedico=convertView.findViewById(R.id.textMedico);
        TextView textPaciente=convertView.findViewById(R.id.textPaciente);
        TextView textFecha=convertView.findViewById(R.id.textFecha);
        TextView textEstado=convertView.findViewById(R.id.textEstado);
        textMedico.setText( json.optString("doctor"));
        textPaciente.setText( json.optString("paciente"));

        String fechaC=new Date(json.optLong("fecha")).toString();
        textFecha.setText(fechaC);
        textEstado.setText( json.optInt("estado")==0?"Activa": "Inactiva");

        String tipo =getApplicationContext().getSharedPreferences("saveMap",0).getString("tipo", null);
        Button asistio = convertView.findViewById(R.id.btnAtendido);
        Button falto = convertView.findViewById(R.id.btnFalto);
        final EditText receta= convertView.findViewById(R.id.receta);

        final Context c=this;
        if ("paciente".equals(tipo)){
            asistio.setVisibility(View.GONE);
            falto.setVisibility(View.GONE);
            receta.setVisibility(View.GONE);
        }else{
            asistio.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {

                    JSONObject obj = new JSONObject();
                    try {
                        obj.put("id", json.optInt("id"));
                        obj.put("receta",receta.getText().toString());

                        ColaApiWeb.post(c,"citas/atendio",obj,MainActivity.class,"No se pudo registrar asistencia");

                    }catch (Exception e){

                    }

                }
            });

            falto.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {

                    JSONObject obj = new JSONObject();
                    try {
                        obj.put("id", json.optInt("id"));
                        ColaApiWeb.post(c,"citas/falto",obj,MainActivity.class,"No se pudo realizar la operacion");

                    }catch (Exception e){

                    }

                }
            });
        }

        Button cancelar=convertView.findViewById(R.id.btnCancelar);

        cancelar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                JSONObject obj = new JSONObject();
                try {
                    obj.put("id", json.optInt("id"));
                    ColaApiWeb.post(c,"citas/cancelar",obj,MainActivity.class,"No se pudo cancelar la cita");

                }catch (Exception e){

                }

            }
        });
    }

    @Override
    public int getItemLayout() {
        return R.layout.item_listar_cita;
    }

    @Override
    public String getWS() {
        return "citas";
    }
}

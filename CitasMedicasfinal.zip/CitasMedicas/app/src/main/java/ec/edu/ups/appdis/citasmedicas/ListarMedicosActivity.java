package ec.edu.ups.appdis.citasmedicas;

import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import org.json.JSONObject;

public class ListarMedicosActivity extends ListarActivity {
    public void registrar(View v)
    {
        Intent intent = new Intent(this,RegistroMedico.class);
        startActivity(intent);
    }

    @Override
    public String[] camposBusqueda() {
        return new String[]{
                "apellido","nombre","especialidadMedico"
        };
    }


    public void bindView(JSONObject json, View convertView) {

        TextView textMedico=convertView.findViewById(R.id.textMedicos);

        final int id = json.optInt("identrymedico");
        final String medico = json.optString("nombre")
                + " " + json.optString("apellido")
                + " " + json.optString("especialidadMedico");
        textMedico.setText(medico);

        Button cita = convertView.findViewById(R.id.btncita);
        cita.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View view) {
                startActivity(
                        new Intent(getBaseContext(),RegistroCita.class)
                                .putExtra("idmedico", id)
                                .putExtra("nombremedico", medico)
                );
            }
        });
    }

    @Override
    public int getItemLayout() {
        return R.layout.item_listar_medicos;
    }

    @Override
    public String getWS() {
        return "medicos";
    }
}

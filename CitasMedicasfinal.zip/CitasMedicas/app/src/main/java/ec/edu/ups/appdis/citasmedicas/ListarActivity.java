package ec.edu.ups.appdis.citasmedicas;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.ListView;
import android.widget.TextView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONObject;

/**
 * Created by Chrys on 10/01/2018.
 */

public abstract class ListarActivity extends Activity {

    public abstract  String[] camposBusqueda();
    public abstract void bindView(JSONObject json, View convertView);
    public abstract int getItemLayout();
    public abstract String getWS();

    private class JsonArrayAdapter extends BaseAdapter implements Filterable {
        private Context context;
        private JSONArray jsonArrayBackup;

        public JsonArrayAdapter(Context c){
            this.context=c;
            this.setArray(new JSONArray());
        }

        JSONArray jsonArray;

        @NonNull
        @Override
        public Filter getFilter() {
            Filter filter=new Filter() {
                @Override
                protected FilterResults performFiltering(CharSequence paramSearch) {

                    JSONArray resultsArray = new JSONArray();

                    for (int i=0;i<jsonArrayBackup.length();i++){
                        JSONObject obj=jsonArrayBackup.optJSONObject(i);
                        boolean encontrado = false;
                        for (String campo : camposBusqueda() ){
                            String value=obj.optString(campo, "").toLowerCase();
                            encontrado = encontrado || value.contains(paramSearch.toString().toLowerCase());
                        }
                        if (
                                encontrado
                                ){
                            resultsArray.put(obj);
                        }
                    }

                    FilterResults filterResults=new FilterResults();
                    filterResults.count=resultsArray.length();
                    filterResults.values=resultsArray;
                    return filterResults;
                }

                @Override
                protected void publishResults(CharSequence charSequence, FilterResults filterResults) {
                    jsonArray= (JSONArray) filterResults.values;
                    notifyDataSetChanged();
                }
            };
            return filter;
        }

        @Override
        public int getCount() {
            return jsonArray.length();
        }

        @Override
        public Object getItem(int i) {
            return jsonArray.opt(i);
        }

        @Override
        public long getItemId(int i) {
            return i;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            if (convertView == null){
                convertView = LayoutInflater.from(context).inflate(getItemLayout(),parent, false);
            }
            bindView((JSONObject) this.getItem(position),convertView);
            return convertView;
        }

        public void setArray(JSONArray array) {
            this.jsonArray = array;
            this.jsonArrayBackup=array;
            notifyDataSetChanged();
        }
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout_listar);

        ListView listaGenerica = findViewById(R.id.listaGenerica);
        final JsonArrayAdapter adapter = new JsonArrayAdapter(this);

        listaGenerica.setAdapter(adapter);
        EditText txtBuscar=findViewById(R.id.txtBuscar);
        txtBuscar.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                adapter.getFilter().filter(charSequence);
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });

        String sesion =getApplicationContext().getSharedPreferences("saveMap",0).getString("sesion", null);
        if(sesion==null) {
            Intent intent = new Intent(this, Login.class);
            startActivity(intent);
            return;
        }

        RequestQueue queue= Volley.newRequestQueue(this);
        JsonArrayRequest request = new JsonArrayRequest(

                Request.Method.GET,
                "http://192.168.2.100:8080/ProyectoCitas/srv/"+ getWS()+"?sesion="+ sesion,
                null,
                new Response.Listener<JSONArray>() {
                    @Override
                    public void onResponse(JSONArray response) {
                        adapter.setArray(response);
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        System.out.println("error" +  error.getMessage());
                    }
                }
        );
        queue.add(request);

    }
}

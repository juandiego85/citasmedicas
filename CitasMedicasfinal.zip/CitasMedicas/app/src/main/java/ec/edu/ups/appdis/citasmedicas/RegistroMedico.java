package ec.edu.ups.appdis.citasmedicas;

import android.os.Bundle;
import android.app.Activity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

public class RegistroMedico extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registro_medico);

        Spinner cmbxEspecialidad = findViewById(R.id.cmbxEspecialidad);
        ArrayAdapter <CharSequence> adapter = ArrayAdapter.createFromResource(this,R.array.especialidades_array,android.R.layout.simple_spinner_item);
        cmbxEspecialidad.setAdapter(adapter);

    }

    public void registrarMedico(View v){

        EditText cedula = findViewById(R.id.txtCedula);
        EditText nombre = findViewById(R.id.txtNombre);
        EditText apellido = findViewById(R.id.txtApellido);
        EditText telefono = findViewById(R.id.txtTelefono);
        EditText correo = findViewById(R.id.txtCorreo);
        EditText clave = findViewById(R.id.txtClave);

        Spinner cmbxEspecialidad = findViewById(R.id.cmbxEspecialidad);

        JSONObject obj= new JSONObject();

        try {
            obj.put("cedula", cedula.getText().toString());
            obj.put("nombre", nombre.getText().toString());
            obj.put("apellido", apellido.getText().toString());
            obj.put("telefono",telefono.getText().toString());
            obj.put("correo", correo.getText().toString());
            obj.put("clave", clave.getText().toString());
            obj.put("especialidadMedico", cmbxEspecialidad.getSelectedItem().toString());
        }catch(JSONException e){
            System.out.println("esta mal parametros");
        }
        RequestQueue queue = Volley.newRequestQueue(this);
        JsonObjectRequest request = new JsonObjectRequest(
                Request.Method.POST,
                "http://192.168.2.100:8080/ProyectoCitas/srv/medicos",
                obj,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        System.out.println("entro aqui");
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        System.out.println("error" + error.getMessage());
                    }
                }
        );
        queue.add(request);
    }

}

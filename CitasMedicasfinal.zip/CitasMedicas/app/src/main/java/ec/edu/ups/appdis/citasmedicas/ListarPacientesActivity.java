package ec.edu.ups.appdis.citasmedicas;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONObject;

public class ListarPacientesActivity extends ListarActivity {

    public void registrar(View v)
    {
        Intent intent = new Intent(this,RegistroPacientes.class);
        startActivity(intent);
    }

    @Override
    public String[] camposBusqueda() {
        return new String[]{
                "nombre", "apellido", "cedula"
        };
    }

    @Override
    public void bindView(JSONObject json, View convertView) {
        TextView textPaciente=convertView.findViewById(R.id.textPacientes);
        textPaciente.setText(
                json.optString("nombre")
                        + " " + json.optString("apellido")
        );

    }

    @Override
    public int getItemLayout() {
        return R.layout.item_listar_pacientes;
    }

    @Override
    public String getWS() {
        return "pacientes";
    }
}

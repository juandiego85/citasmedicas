package ec.edu.ups.appdis.citasmedicas;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;

public class MainActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        String sesion =getApplicationContext().getSharedPreferences("saveMap",0).getString("sesion", null);
        if(sesion==null) {
            Intent intent = new Intent(this, Login.class);
            startActivity(intent);
        }
        ColaApiWeb.getInstance(this);
        String tipo =getApplicationContext().getSharedPreferences("saveMap",0).getString("tipo", null);
        if ("paciente".equals(tipo)){
            LinearLayout layPaciente=findViewById(R.id.layPaciente);
            layPaciente.setVisibility(View.GONE);
        }

    }

    public void listarMedicos(View v)
    {
        System.out.println("ingreso listar medicos");
        Intent intent = new Intent(this,ListarMedicosActivity.class);
        startActivity(intent);
    }

    public void listarPacientes(View v)
    {
        Intent intent = new Intent(this,ListarPacientesActivity.class);
        startActivity(intent);
    }
    public void listarCitas(View v)
    {
        Intent intent = new Intent(this,ListarCitasActivity.class);
        startActivity(intent);
    }
}

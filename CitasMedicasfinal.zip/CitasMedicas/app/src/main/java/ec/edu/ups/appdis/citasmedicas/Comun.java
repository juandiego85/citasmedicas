package ec.edu.ups.appdis.citasmedicas;

import java.util.regex.Pattern;

/**
 * Created by Chrys on 10/01/2018.
 */

public class Comun {

    public static final String urlWs = "http://192.168.2.100:8080/ProyectoCitas/srv";

    public static boolean Validacion(String patron, String campo){

        return Pattern.compile(patron).matcher(campo).matches()==false;
    }
}

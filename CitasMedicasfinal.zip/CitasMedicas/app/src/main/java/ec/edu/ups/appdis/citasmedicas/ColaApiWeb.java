package ec.edu.ups.appdis.citasmedicas;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.widget.Toast;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.Calendar;

/**
 * Created by Chrys on 23/01/2018.
 */

public class ColaApiWeb {

    private static ColaApiWeb instance;
    public static synchronized ColaApiWeb getInstance(Context context){

        if (instance==null){
            instance = new ColaApiWeb(context);
        }
        return instance;
    }
    private RequestQueue queue;
    private Calendar c=Calendar.getInstance();

    JsonArrayRequest makeRequest(final Context context){
        String sesion=context.getSharedPreferences("saveMap",0).getString("sesion", null);
       JsonArrayRequest request=  new JsonArrayRequest(

             Request.Method.GET,
             "http://192.168.2.100:8080/ProyectoCitas/srv/citas/n?sesion="+ sesion + "&desde="+c.getTimeInMillis(),
             null,
             new Response.Listener<JSONArray>() {
                 @Override
                 public void onResponse(JSONArray response) {
                     for (int i=0;i<response.length();i++){
                         JSONObject n=response.optJSONObject(i);
                         long fecha = n.optLong("fecha",System.currentTimeMillis());
                         c.setTimeInMillis(fecha);
                         String mensaje=n.optString("mensaje","no hay texto");
                         System.out.println("Llego la notificacion: " + mensaje);


                         Notification.Builder builder=new Notification.Builder(context);
                         builder.setSmallIcon(R.drawable.citas)
                                 .setContentText(mensaje)
                                 .setContentTitle("Citas Medicas");

                         NotificationManager notificationManager= (NotificationManager) context.getSystemService(context.NOTIFICATION_SERVICE);
                         notificationManager.notify(1,builder.build());
                     }
                     queue.add(makeRequest(context));
                 }
             },
             new Response.ErrorListener() {
                 @Override
                 public void onErrorResponse(VolleyError error) {
                     System.out.println("error notificacion" +  error.getMessage());
                     queue.add(makeRequest(context));
                 }
             }
     );
       request.setRetryPolicy(new DefaultRetryPolicy(15000,DefaultRetryPolicy.DEFAULT_MAX_RETRIES,DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
       return request;
    }
    private ColaApiWeb(Context context){


        queue= Volley.newRequestQueue(context.getApplicationContext());
        queue.add(makeRequest(context.getApplicationContext()));
    }
    public static void post(final Context context, final String servicio, JSONObject json, final Class<?> cls, final String e){
        String url="http://192.168.2.100:8080/ProyectoCitas/srv/"+servicio;

        String sesion = context.getSharedPreferences("saveMap",0).getString("sesion", "");

        if (sesion!=null){
            try {
                json.put("sesion",sesion);
            } catch (JSONException e1) {
                e1.printStackTrace();
            }
        }
       // final ProgressDialog p = new ProgressDialog(context);
        //p.setIndeterminate(true);
        JsonObjectRequest request = new JsonObjectRequest(
                Request.Method.POST,
                url,
                json,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                      //  p.dismiss();
                        String estado=response.optString("estado","fallo");
                        if (estado.equalsIgnoreCase("ok")){
                            Toast.makeText(context, "Operacion exitosa", Toast.LENGTH_SHORT).show();
                            Intent intent=new Intent(context, cls);
                            context.startActivity(intent);
                        }else{
                            Toast.makeText(context, e, Toast.LENGTH_SHORT).show();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                       // p.dismiss();
                        Toast.makeText(context, e, Toast.LENGTH_SHORT).show();
                        System.out.println("error en " +servicio + " : " + error.getMessage());
                    }
                }
        );
       // p.show();
        System.out.println(sesion+"----->"+url);
        instance.queue.add(request);
    }

}

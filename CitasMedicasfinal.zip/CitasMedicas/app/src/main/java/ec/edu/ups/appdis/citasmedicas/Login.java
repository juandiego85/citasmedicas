package ec.edu.ups.appdis.citasmedicas;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

public class Login extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
    }

    public void login (View v){

        EditText correo = findViewById(R.id.txtCorreo);
        EditText clave = findViewById(R.id.txtClave);

        JSONObject obj= new JSONObject();

        try {
            obj.put("correo", correo.getText().toString());
            obj.put("clave", clave.getText().toString());

        }catch(JSONException e){
            System.out.println("esta mal parametros");
        }
        RequestQueue queue = Volley.newRequestQueue(this);
        JsonObjectRequest request = new JsonObjectRequest(
                Request.Method.POST,
                "http://192.168.2.100:8080/ProyectoCitas/srv/login",
                obj,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        String resp= response.optString("resul");
                        if ("fallo".equals(resp)){
                            Toast.makeText(getBaseContext(), "Clave Incorrecta", Toast.LENGTH_SHORT).show();
                            return ;
                        }
                        String nombre= response.optString("nombre");
                        String tipo=response.optString("tipo");
                        getApplicationContext()
                                .getSharedPreferences("saveMap",0)
                                .edit()
                                .putString("sesion", resp)
                                .putString("nombre",nombre)
                                .putString("tipo",tipo)
                                .apply();

                        Intent i=new Intent(getBaseContext(),MainActivity.class);
                        startActivity(i);

                       /* getApplicationContext()
                                .getSharedPreferences("saveMap",0)
                                .edit().clear().apply();*/
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        System.out.println("error" + error.toString());
                    }
                }
        );
        queue.add(request);
    }
}

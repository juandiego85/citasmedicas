package ec.edu.ups.appdis.citasmedicas;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

public class RegistroPacientes extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registro_pacientes);
    }

    public void registrarPaciente (View v) {

        EditText cedula = findViewById(R.id.txtCedula);
        EditText nombre = findViewById(R.id.txtNombre);
        EditText apellido = findViewById(R.id.txtApellido);
        EditText telefono = findViewById(R.id.txtTelefono);
        EditText correo = findViewById(R.id.txtCorreo);
        EditText clave = findViewById(R.id.txtClave);

        if(Comun.Validacion("^[0-9]{10}$",cedula.getText().toString())){
            Toast.makeText(getApplicationContext(),"Cedula Invalida",Toast.LENGTH_LONG).show();
            return;
        }

        JSONObject obj = new JSONObject();


        try {
            obj.put("cedula", cedula.getText().toString());
            obj.put("nombre", nombre.getText().toString());
            obj.put("apellido", apellido.getText().toString());
            obj.put("telefono", telefono.getText().toString());
            obj.put("correo", correo.getText().toString());
            obj.put("clave", clave.getText().toString());

        } catch (JSONException e) {
            System.out.println("esta mal parametros");
        }
        RequestQueue queue = Volley.newRequestQueue(this);
        JsonObjectRequest request = new JsonObjectRequest(
                Request.Method.POST,
                "http://192.168.2.100:8080/ProyectoCitas/srv/pacientes",
                obj,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        System.out.println("entro aqui");
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        System.out.println("error" + error.getMessage());
                    }
                }
        );
        queue.add(request);
    }
}

package ec.edu.ups.appdis.citasmedicas;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.TimePicker;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class RegistroCita extends Activity implements TimePickerDialog.OnTimeSetListener, DatePickerDialog.OnDateSetListener{

    private Calendar c = Calendar.getInstance();
    private TimePickerDialog tiempo;
    private DatePickerDialog fecha;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registro_cita);

        tiempo = new TimePickerDialog(this,this,0,0, true);
        fecha  = new DatePickerDialog(this,this,2018,1,23);

        Intent intent = getIntent();
        String nombrePaciente = getApplicationContext().getSharedPreferences("saveMap",0).getString("nombre", "");
        String nombreMedico = intent.getStringExtra("nombremedico");

        TextView doctor= findViewById(R.id.idMedico);
        TextView paciente=findViewById(R.id.idPaciente);
        doctor.setText(nombreMedico);
        paciente.setText(nombrePaciente);

    }
    public void registrarCita(View v){

        Intent intent = getIntent();
        int idDoctor = intent.getIntExtra("idmedico",0);
        String sesion = getApplicationContext().getSharedPreferences("saveMap",0).getString("sesion", "");

        JSONObject obj = new JSONObject();
        try {
            obj.put("doctor", idDoctor);
            obj.put("fecha", c.getTimeInMillis());
            obj.put("sesion",sesion);
            ColaApiWeb.post(this,"citas",obj,MainActivity.class,"No se pudo registrar la cita");
        }catch (Exception e){

        }

    }

    @Override
    public void onTimeSet(TimePicker timePicker, int horas, int minutos) {
        c.set(Calendar.HOUR_OF_DAY ,horas);
        c.set(Calendar.MINUTE,15*(1+minutos/15));
        c.set(Calendar.SECOND,0);
        c.set(Calendar.MILLISECOND,0);
        EditText hora= findViewById(R.id.txtHora);
        hora.setText(new SimpleDateFormat("HH:mm").format(c.getTime()));
    }

    @Override
    public void onDateSet(DatePicker datePicker, int year, int month, int day) {
        c.set(Calendar.YEAR,year);
        c.set(Calendar.MONTH,month);
        c.set(Calendar.DAY_OF_MONTH,day);
        EditText fecha= findViewById(R.id.txtDate);
        fecha.setText(new SimpleDateFormat("dd-MM-yyyy").format(c.getTime()));
    }

    public void registrarFecha(View v){
        fecha.show();
    }
    public void registrarHora(View v){
        tiempo.show();
    }

}
